Migration Plan: Upgrade to Java 21

Migration Session ID: 0c00a4d2-12dd-4bc7-8c67-602d9c8e7ccb
Plan created: 2025-12-19 19:04:58

**Uncommitted Changes Policy**: Always Stash

**Target branch**: appmod/java-migration-20251219190458

**Programming Language**: java

## 0. Pre-Condition Check
- Java source files: detected
- Build files: none found (`pom.xml`, `build.gradle`, `build.gradle.kts` not present)

## 1. Detected Files (examples)
- src/main/java/com/educhatbot/Application.java
- src/main/java/com/educhatbot/ai/ChatbotEngine.java
- src/main/java/com/educhatbot/ui/ChatbotGUI.java
- src/main/java/com/educhatbot/utils/Message.java
- src/main/java/com/educhatbot/utils/Logger.java

## 2. JDK Settings
- Installed JDKs discovered:
  - Java 1.8.0_462 — C:\Users\HP\AppData\Local\Programs\Eclipse Adoptium\jdk-8.0.462.8-hotspot\bin
  - Java 25.0.1 — C:\Program Files\Java\jdk-25\bin
- Need to install new JDK for target Java 21: true (Java 21 not found)
- JAVA_HOME: N/A (no LTS 21 set as JAVA_HOME)
- Install path (if installing): C:\Users\HP\.jdk
- JDK to install: 21 (LTS)

## 3. Build Tool Settings
- Build tool detected: none
- Recommended: Maven (create `pom.xml`) — preferred if user agrees
- Wrapper detected: none
- MAVEN_HOME: N/A
- If installing Maven, install path: C:\Users\HP\.maven

## 4. Files to Update (initial ordering)
Order will be determined by dependency analysis; initial set includes:
- src/main/java/com/educhatbot/utils/Message.java
- src/main/java/com/educhatbot/utils/Logger.java
- src/main/java/com/educhatbot/ai/ChatbotEngine.java
- src/main/java/com/educhatbot/ui/ChatbotGUI.java
- src/main/java/com/educhatbot/Application.java

## 5. High-level Plan
1. Version control setup: check status, stash uncommitted changes (policy: Always Stash), create branch `appmod/java-migration-20251219190458`.
2. Install JDK 21 to `C:\Users\HP\\.jdk` (tool: `install_jdk`) if user confirms; set JAVA_HOME accordingly in plan.
3. Add a Maven `pom.xml` (or Gradle if preferred) and a CI-friendly build configuration.
4. Update `maven-compiler-plugin` / `java.version` to 21.
5. Run `build_java_project` (session: 0c00a4d2-12dd-4bc7-8c67-602d9c8e7ccb) and fix build issues.
6. Run `run_tests_for_java` (session: 0c00a4d2-12dd-4bc7-8c67-602d9c8e7ccb) and address failing unit tests.
7. Validation & Fix loop (CVE scan, Build, Consistency, Tests, Completeness) until stable.
8. Final commit and generate migration summary.

## 6. Next Actions (immediate)
- Create progress tracking file `./.github/appmod/code-migration/20251219190458/progress.md` and mark current statuses.
- Perform version control setup (check status, stash per policy, create branch).

## 7. Notes for the user
- The repository currently lacks a build file; automated build/test steps require adding a `pom.xml` or `build.gradle` before `build_java_project` can run.
- The plan will install JDK 21 to `C:\Users\HP\\.jdk` if a suitable JDK 21 isn't available.
- All version-control operations will use the appmod-version-control tool as required.
